package com.divinesword.mod.command;

import com.divinesword.mod.item.DivineSwordItem;
import com.divinesword.mod.item.ModItems;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public class DivineSwordCommands {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("divinesword")
            .then(Commands.literal("claim")
                .executes(ctx -> claimSword(ctx.getSource())))
            .then(Commands.literal("give")
                .executes(ctx -> giveSword(ctx.getSource())))
            .then(Commands.literal("summon")
                .executes(ctx -> summonSword(ctx.getSource())))
            .then(Commands.literal("stones")
                .then(Commands.argument("count", StringArgumentType.word())
                    .executes(ctx -> giveStones(ctx.getSource(),
                        Integer.parseInt(StringArgumentType.getString(ctx, "count"))))))
            .then(Commands.literal("armor")
                .executes(ctx -> giveArmor(ctx.getSource())))
        );
    }

    // /divinesword claim — set yourself as owner of held sword
    private static int claimSword(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ItemStack held = player.getMainHandItem();

        if (!(held.getItem() instanceof DivineSwordItem)) {
            source.sendFailure(Component.literal("You must hold the Divine Sword to claim it!"));
            return 0;
        }

        DivineSwordItem.setOwner(held, player.getUUID());
        source.sendSuccess(() -> Component.literal("✦ You are now the chosen wielder of the Divine Sword! ✦")
            .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), true);
        return 1;
    }

    // /divinesword give — give yourself a new divine sword
    private static int giveSword(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ItemStack sword = new ItemStack(ModItems.DIVINE_SWORD.get());
        DivineSwordItem.setOwner(sword, player.getUUID());
        player.getInventory().add(sword);
        source.sendSuccess(() -> Component.literal("✦ Divine Sword granted and bound to you! ✦")
            .withStyle(ChatFormatting.GOLD), true);
        return 1;
    }

    // /divinesword summon — pull sword from inventory to hand
    private static int summonSword(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();

        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack slot = player.getInventory().getItem(i);
            if (slot.getItem() instanceof DivineSwordItem && DivineSwordItem.isOwner(slot, player)) {
                if (i < 9) {
                    player.getInventory().selected = i;
                } else {
                    ItemStack current = player.getMainHandItem().copy();
                    player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, slot.copy());
                    player.getInventory().setItem(i, current);
                }
                source.sendSuccess(() -> Component.literal("✦ Divine Sword summoned! ✦")
                    .withStyle(ChatFormatting.GOLD), false);
                return 1;
            }
        }

        source.sendFailure(Component.literal("No bound Divine Sword found in your inventory!"));
        return 0;
    }

    // /divinesword stones <count> — give power stones 1-3
    private static int giveStones(CommandSourceStack source, int count) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        int given = Math.min(count, 3);
        if (given >= 1) player.getInventory().add(new ItemStack(ModItems.POWER_STONE_1.get()));
        if (given >= 2) player.getInventory().add(new ItemStack(ModItems.POWER_STONE_2.get()));
        if (given >= 3) player.getInventory().add(new ItemStack(ModItems.POWER_STONE_3.get()));
        source.sendSuccess(() -> Component.literal("✦ " + given + " Power Stone(s) given! ✦")
            .withStyle(ChatFormatting.GOLD), false);
        return 1;
    }

    // /divinesword armor — give the full divine armor set
    private static int giveArmor(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        player.getInventory().add(new ItemStack(ModItems.DIVINE_HELMET.get()));
        player.getInventory().add(new ItemStack(ModItems.DIVINE_CHESTPLATE.get()));
        player.getInventory().add(new ItemStack(ModItems.DIVINE_LEGGINGS.get()));
        player.getInventory().add(new ItemStack(ModItems.DIVINE_BOOTS.get()));
        source.sendSuccess(() -> Component.literal("✦ Divine Armor Set given! ✦")
            .withStyle(ChatFormatting.GOLD), false);
        return 1;
    }
}
