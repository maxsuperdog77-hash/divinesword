package com.divinesword.mod.util;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public class DivineSwordEffects {

    /**
     * Spawns the sacred floating rune symbols + lightning ring around player.
     * Called from server tick every 10 ticks while holding the sword.
     */
    public static void spawnWielderAura(Player player, ServerLevel level, int powerLevel) {
        Vec3 pos = player.position();
        double r = 1.5;

        // Orbit particles
        for (int i = 0; i < 8; i++) {
            double angle = (level.getGameTime() * 0.1 + i * Math.PI / 4);
            double x = pos.x + Math.cos(angle) * r;
            double z = pos.z + Math.sin(angle) * r;
            double y = pos.y + 1.0 + Math.sin(level.getGameTime() * 0.05 + i) * 0.3;
            level.sendParticles(ParticleTypes.END_ROD, x, y, z, 1, 0, 0, 0, 0.01);
        }

        // Fire pillar at feet
        level.sendParticles(ParticleTypes.FLAME,
            pos.x, pos.y, pos.z, 3, 0.3, 0, 0.3, 0.02);

        // Additional particles based on power level
        if (powerLevel >= 50) {
            level.sendParticles(ParticleTypes.ENCHANT,
                pos.x, pos.y + 1, pos.z, 5, 0.5, 0.5, 0.5, 0.1);
        }
        if (powerLevel >= 75) {
            level.sendParticles(ParticleTypes.LAVA,
                pos.x, pos.y, pos.z, 2, 0.5, 0, 0.5, 0.02);
        }
        if (powerLevel >= 100) {
            // Floating rune-like symbols via soul fire
            for (int i = 0; i < 4; i++) {
                double angle = (level.getGameTime() * 0.08 + i * Math.PI / 2);
                level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                    pos.x + Math.cos(angle) * 2,
                    pos.y + 1.5,
                    pos.z + Math.sin(angle) * 2,
                    1, 0, 0.1, 0, 0.02);
            }
        }
        if (powerLevel == 120) {
            level.sendParticles(ParticleTypes.EXPLOSION,
                pos.x, pos.y + 0.5, pos.z, 1, 0.2, 0.2, 0.2, 0.01);
        }
    }

    /**
     * Spawns the holy sun effect behind the wielder.
     * Uses a ring of end_rod + flame particles at head height behind player.
     */
    public static void spawnHolySun(Player player, ServerLevel level) {
        Vec3 pos = player.position();
        Vec3 look = player.getLookAngle();
        // Behind the player = opposite of look direction
        double bx = pos.x - look.x * 2.5;
        double bz = pos.z - look.z * 2.5;
        double by = pos.y + 1.6;

        double sunR = 1.2;
        long t = level.getGameTime();
        for (int i = 0; i < 12; i++) {
            double angle = (t * 0.05 + i * Math.PI / 6);
            double sx = bx + Math.cos(angle) * sunR;
            double sz = bz + Math.sin(angle) * sunR;
            level.sendParticles(ParticleTypes.END_ROD, sx, by, sz, 1, 0, 0, 0, 0.005);
        }
        // Sun core glow
        level.sendParticles(ParticleTypes.FLASH, bx, by, bz, 1, 0, 0, 0, 0);
    }

    /**
     * Lightning sparks around sword wielder — continuous effect.
     */
    public static void spawnLightningSparks(Player player, ServerLevel level) {
        Vec3 pos = player.position();
        for (int i = 0; i < 3; i++) {
            double ox = (Math.random() - 0.5) * 2;
            double oy = Math.random() * 2;
            double oz = (Math.random() - 0.5) * 2;
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                pos.x + ox, pos.y + oy, pos.z + oz, 1, 0, 0, 0, 0.05);
        }
    }

    /**
     * Stone-wave effect near the blade.
     */
    public static void spawnStoneWave(Player player, ServerLevel level) {
        Vec3 pos = player.position();
        Vec3 look = player.getLookAngle();
        for (int i = 1; i <= 4; i++) {
            level.sendParticles(ParticleTypes.CRIT,
                pos.x + look.x * i * 0.7,
                pos.y + 1.0 + look.y * i * 0.5,
                pos.z + look.z * i * 0.7,
                2, 0.1, 0.1, 0.1, 0.05);
        }
    }

    /**
     * Lava geyser eruption for 75% ability.
     */
    public static void spawnLavaGeyser(ServerLevel level, BlockPos center, int radius) {
        for (int i = 0; i < 20; i++) {
            double angle = Math.random() * Math.PI * 2;
            double r = Math.random() * radius;
            double x = center.getX() + Math.cos(angle) * r;
            double z = center.getZ() + Math.sin(angle) * r;
            level.sendParticles(ParticleTypes.LAVA, x, center.getY(), z, 5, 0.3, 1.0, 0.3, 0.1);
            level.sendParticles(ParticleTypes.LARGE_SMOKE, x, center.getY(), z, 3, 0.2, 0.5, 0.2, 0.05);
        }
    }

    /**
     * Heaven's judgment beam effect from sky.
     */
    public static void spawnHeavenBeams(ServerLevel level, BlockPos center, int count) {
        for (int i = 0; i < count; i++) {
            double angle = Math.random() * Math.PI * 2;
            double r = Math.random() * 60;
            double x = center.getX() + Math.cos(angle) * r;
            double z = center.getZ() + Math.sin(angle) * r;
            // Beam from y=300 down to ground
            for (int y = 300; y > center.getY(); y -= 5) {
                level.sendParticles(ParticleTypes.END_ROD, x, y, z, 1, 0.1, 0, 0.1, 0.01);
            }
        }
    }
}
