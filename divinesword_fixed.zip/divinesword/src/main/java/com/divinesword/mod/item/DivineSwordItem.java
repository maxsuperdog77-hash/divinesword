package com.divinesword.mod.item;

import com.divinesword.mod.event.ModEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

import javax.annotation.Nullable;
import java.util.List;
import java.util.UUID;

public class DivineSwordItem extends SwordItem {

    public static final String TAG_OWNER = "SwordOwner";
    public static final String TAG_STONES = "StonesInserted";
    public static final String TAG_KILLS = "KillCount";
    public static final String TAG_HITS = "HitCount";
    public static final String TAG_COOLDOWN_25 = "Cooldown25";
    public static final String TAG_COOLDOWN_50 = "Cooldown50";
    public static final String TAG_COOLDOWN_75 = "Cooldown75";
    public static final String TAG_COOLDOWN_100 = "Cooldown100";
    public static final String TAG_COOLDOWN_120 = "Cooldown120";
    public static final String TAG_COOLDOWN_LASER = "CooldownLaser";
    public static final String TAG_MERGED = "MergedForm";
    public static final String TAG_MERGE_END = "MergeEndTime";
    public static final String TAG_MERGE_WEAKNESS_END = "MergeWeaknessEnd";
    public static final String TAG_MODE = "PowerMode"; // 0=normal, 1=divine

    // Cooldowns in ticks
    public static final int CD_25 = 30 * 20;
    public static final int CD_50 = 60 * 20;
    public static final int CD_75 = 3 * 60 * 20;
    public static final int CD_100 = 5 * 60 * 20;
    public static final int CD_120 = 10 * 60 * 20;
    public static final int CD_LASER = 50 * 20;
    public static final int MERGE_DURATION = 30 * 20;

    public DivineSwordItem() {
        super(Tiers.NETHERITE, 20, -2.4f, new Item.Properties()
            .stacksTo(1)
            .fireResistant()
            .rarity(Rarity.EPIC));
    }

    // ─── Power Level ─────────────────────────────────────────────────────────

    public static int getPowerLevel(ItemStack stack) {
        int stones = getStones(stack);
        if (stones == 7) return 120; // all 3 stones (bitmask 111)
        if (stones == 4) return 100; // stone 3 only treated as "third" — use count
        // Count bits
        int count = Integer.bitCount(stones & 0x7);
        return switch (count) {
            case 0 -> 25;
            case 1 -> 50;
            case 2 -> 75;
            case 3 -> 100;
            default -> 25;
        };
    }

    public static int getStoneCount(ItemStack stack) {
        return Integer.bitCount(getStones(stack) & 0x7);
    }

    public static int getStones(ItemStack stack) {
        return stack.getOrCreateTag().getInt(TAG_STONES);
    }

    public static boolean insertStone(ItemStack stack, int stoneIndex) {
        int stones = getStones(stack);
        int bit = 1 << (stoneIndex - 1);
        if ((stones & bit) != 0) return false; // already inserted
        stack.getOrCreateTag().putInt(TAG_STONES, stones | bit);
        return true;
    }

    // ─── Ownership ────────────────────────────────────────────────────────────

    public static boolean hasOwner(ItemStack stack) {
        return stack.getOrCreateTag().contains(TAG_OWNER);
    }

    public static UUID getOwner(ItemStack stack) {
        String uuidStr = stack.getOrCreateTag().getString(TAG_OWNER);
        try { return UUID.fromString(uuidStr); } catch (Exception e) { return null; }
    }

    public static void setOwner(ItemStack stack, UUID uuid) {
        stack.getOrCreateTag().putString(TAG_OWNER, uuid.toString());
    }

    public static boolean isOwner(ItemStack stack, Player player) {
        UUID owner = getOwner(stack);
        return owner != null && owner.equals(player.getUUID());
    }

    // ─── Cooldown helpers ─────────────────────────────────────────────────────

    private static long getTick(Level level) {
        return level.getGameTime();
    }

    public static boolean isCooldown(ItemStack stack, String tag, long gameTick) {
        return stack.getOrCreateTag().getLong(tag) > gameTick;
    }

    public static void setCooldown(ItemStack stack, String tag, long gameTick, int ticks) {
        stack.getOrCreateTag().putLong(tag, gameTick + ticks);
    }

    public static long getRemainingCooldown(ItemStack stack, String tag, long gameTick) {
        return Math.max(0, stack.getOrCreateTag().getLong(tag) - gameTick);
    }

    // ─── Kill / XP tracking ───────────────────────────────────────────────────

    public void recordKill(ItemStack stack, int hitsNeeded) {
        CompoundTag tag = stack.getOrCreateTag();
        int kills = tag.getInt(TAG_KILLS) + 1;
        tag.putInt(TAG_KILLS, kills);
        // Bonus damage stored as extra: 1 per (hitsNeeded) kills, max 200
        int bonus = Math.min(200, kills / Math.max(1, hitsNeeded));
        tag.putInt("BonusDamage", bonus);
    }

    public static int getBonusDamage(ItemStack stack) {
        return stack.getOrCreateTag().getInt("BonusDamage");
    }

    // ─── Use (right-click) ────────────────────────────────────────────────────

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (!hasOwner(stack) || !isOwner(stack, player)) {
            player.displayClientMessage(
                Component.literal("✦ Only the chosen wielder may use this blade! ✦")
                    .withStyle(ChatFormatting.GOLD), true);
            return InteractionResultHolder.fail(stack);
        }

        if (level.isClientSide) return InteractionResultHolder.success(stack);

        long tick = getTick(level);

        if (isCooldown(stack, TAG_COOLDOWN_LASER, tick)) {
            long rem = getRemainingCooldown(stack, TAG_COOLDOWN_LASER, tick) / 20;
            player.displayClientMessage(
                Component.literal("⚡ Laser cooldown: " + rem + "s").withStyle(ChatFormatting.RED), true);
            return InteractionResultHolder.fail(stack);
        }

        // Fire a divine laser projectile
        fireLaser(level, player, stack, tick);
        return InteractionResultHolder.success(stack);
    }

    private void fireLaser(Level level, Player player, ItemStack stack, long tick) {
        setCooldown(stack, TAG_COOLDOWN_LASER, tick, CD_LASER);
        level.playSound(null, player.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER,
            SoundSource.PLAYERS, 1.0f, 1.5f);

        // Find entity in sight up to 40 blocks
        var hitResult = player.pick(40, 0, false);
        var eyePos = player.getEyePosition();
        var lookVec = player.getLookAngle();

        AABB searchBox = player.getBoundingBox().expandTowards(lookVec.scale(40)).inflate(1);
        List<Entity> entities = level.getEntities(player, searchBox,
            e -> e instanceof LivingEntity && e.isAlive());

        LivingEntity target = null;
        double closest = Double.MAX_VALUE;
        for (Entity e : entities) {
            double dist = e.distanceToSqr(player);
            if (dist < closest) { closest = dist; target = (LivingEntity) e; }
        }

        if (target != null) {
            target.hurt(level.damageSources().playerAttack(player), 10f); // 5 hearts
            level.playSound(null, target.blockPosition(), SoundEvents.GENERIC_EXPLODE,
                SoundSource.PLAYERS, 0.8f, 1.2f);
            player.displayClientMessage(
                Component.literal("⚡ Divine Laser! -5♥").withStyle(ChatFormatting.YELLOW), true);
        } else {
            player.displayClientMessage(
                Component.literal("⚡ Laser fired! No target in range.").withStyle(ChatFormatting.YELLOW), true);
        }
    }

    // ─── Semicolon Key ability (called from event) ───────────────────────────

    public static void activatePower(ServerPlayer player, ItemStack stack) {
        if (!isOwner(stack, player)) {
            player.displayClientMessage(
                Component.literal("✦ You are not the chosen wielder! ✦").withStyle(ChatFormatting.DARK_RED), true);
            return;
        }

        Level level = player.level();
        long tick = getTick(level);
        int power = getPowerLevel(stack);

        // Check merged form weakness
        if (stack.getOrCreateTag().getLong(TAG_MERGE_WEAKNESS_END) > tick) {
            player.displayClientMessage(
                Component.literal("⚠ You are weakened from the Merge! Cannot use powers.")
                    .withStyle(ChatFormatting.DARK_RED), true);
            return;
        }

        switch (power) {
            case 25 -> activate25(player, stack, level, tick);
            case 50 -> activate50(player, stack, level, tick);
            case 75 -> activate75(player, stack, level, tick);
            case 100 -> activate100(player, stack, level, tick);
            case 120 -> activate120(player, stack, level, tick);
        }
    }

    // 25% — Vampiric Strike
    private static void activate25(ServerPlayer player, ItemStack stack, Level level, long tick) {
        if (isCooldown(stack, TAG_COOLDOWN_25, tick)) {
            showCooldown(player, "Vampiric Strike", getRemainingCooldown(stack, TAG_COOLDOWN_25, tick));
            return;
        }
        setCooldown(stack, TAG_COOLDOWN_25, tick, CD_25);

        // Speed + Strength
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 30, 2));
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 20 * 30, 2));

        // Steal 1 heart from nearest enemy
        AABB box = player.getBoundingBox().inflate(5);
        List<LivingEntity> nearby = level.getEntitiesOfClass(LivingEntity.class, box,
            e -> e != player && e.isAlive());
        if (!nearby.isEmpty()) {
            LivingEntity target = nearby.get(0);
            target.hurt(level.damageSources().playerAttack(player), 2f);
            if (player.getHealth() < player.getMaxHealth()) {
                player.heal(2f);
            } else {
                player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 20 * 10, 0));
            }
        }
        level.playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1f, 0.8f);
        player.displayClientMessage(
            Component.literal("⚔ Vampiric Strike! +1♥ stolen! [30s CD]").withStyle(ChatFormatting.GOLD), true);
    }

    // 50% — Divine Slash
    private static void activate50(ServerPlayer player, ItemStack stack, Level level, long tick) {
        if (isCooldown(stack, TAG_COOLDOWN_50, tick)) {
            showCooldown(player, "Divine Slash", getRemainingCooldown(stack, TAG_COOLDOWN_50, tick));
            return;
        }
        setCooldown(stack, TAG_COOLDOWN_50, tick, CD_50);

        AABB box = player.getBoundingBox().inflate(20);
        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, box,
            e -> e != player && e.isAlive());

        float totalHealed = 0;
        for (LivingEntity e : targets) {
            float dmg = e.getHealth() * 0.5f;
            e.hurt(level.damageSources().playerAttack(player), dmg);
            totalHealed += dmg * 0.1f;
        }
        player.heal(Math.min(totalHealed, player.getMaxHealth() * 0.5f));

        level.playSound(null, player.blockPosition(), SoundEvents.LIGHTNING_BOLT_IMPACT,
            SoundSource.PLAYERS, 1.5f, 0.6f);
        player.displayClientMessage(
            Component.literal("⚔ Divine Slash! Hit " + targets.size() + " enemies within 20 blocks! [1m CD]")
                .withStyle(ChatFormatting.GOLD), true);
    }

    // 75% — Volcanic Eruption
    private static void activate75(ServerPlayer player, ItemStack stack, Level level, long tick) {
        if (isCooldown(stack, TAG_COOLDOWN_75, tick)) {
            showCooldown(player, "Volcanic Eruption", getRemainingCooldown(stack, TAG_COOLDOWN_75, tick));
            return;
        }
        setCooldown(stack, TAG_COOLDOWN_75, tick, CD_75);

        if (!(level instanceof ServerLevel serverLevel)) return;

        BlockPos center = player.blockPosition();

        // Spawn lava geysers and fire
        for (int i = 0; i < 12; i++) {
            double angle = (i / 12.0) * Math.PI * 2;
            int radius = 5 + (i % 3) * 5;
            BlockPos pos = center.offset(
                (int)(Math.cos(angle) * radius),
                0,
                (int)(Math.sin(angle) * radius));

            // Spawn lightning for dramatic effect
            net.minecraft.world.entity.LightningBolt bolt = new net.minecraft.world.entity.LightningBolt(
                net.minecraft.world.entity.EntityType.LIGHTNING_BOLT, serverLevel);
            bolt.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
            bolt.setVisualOnly(false);
            serverLevel.addFreshEntity(bolt);
        }

        // Burn everything in 25 blocks
        AABB box = player.getBoundingBox().inflate(25);
        List<LivingEntity> targets = serverLevel.getEntitiesOfClass(LivingEntity.class, box,
            e -> e != player && e.isAlive());
        for (LivingEntity e : targets) {
            e.setSecondsOnFire(15);
            e.hurt(serverLevel.damageSources().lava(), 20f);
        }

        serverLevel.playSound(null, center, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 2f, 0.5f);
        player.displayClientMessage(
            Component.literal("🌋 Volcanic Eruption! Everything within 25 blocks is burning! [3m CD]")
                .withStyle(ChatFormatting.RED), true);
    }

    // 100% — Heaven's Judgment
    private static void activate100(ServerPlayer player, ItemStack stack, Level level, long tick) {
        if (isCooldown(stack, TAG_COOLDOWN_100, tick)) {
            showCooldown(player, "Heaven's Judgment", getRemainingCooldown(stack, TAG_COOLDOWN_100, tick));
            return;
        }
        setCooldown(stack, TAG_COOLDOWN_100, tick, CD_100);

        if (!(level instanceof ServerLevel serverLevel)) return;

        // Announce
        serverLevel.getServer().getPlayerList().broadcastSystemMessage(
            Component.literal("⚡ " + player.getName().getString() +
                " raises the Divine Sword to the heavens! ALL SHALL PERISH! ⚡")
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);

        // Ascend
        player.setDeltaMovement(0, 2.5, 0);
        player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 20 * 3, 0));

        // Schedule the crash and mass annihilation (via ModEvents tick tracking)
        stack.getOrCreateTag().putLong("HeavenJudgmentTick", tick + 60); // 3 seconds
        stack.getOrCreateTag().putBoolean("HeavenJudgmentPending", true);
        stack.getOrCreateTag().putString("HeavenJudgmentPlayer", player.getUUID().toString());
    }

    public static void executeHeavensJudgment(ServerPlayer player, ItemStack stack, ServerLevel level) {
        stack.getOrCreateTag().remove("HeavenJudgmentPending");

        BlockPos center = player.blockPosition();

        // Lightning storm over 60 block radius
        for (int i = 0; i < 30; i++) {
            double angle = Math.random() * Math.PI * 2;
            int r = (int)(Math.random() * 60);
            BlockPos pos = center.offset((int)(Math.cos(angle)*r), 0, (int)(Math.sin(angle)*r));
            net.minecraft.world.entity.LightningBolt bolt = new net.minecraft.world.entity.LightningBolt(
                net.minecraft.world.entity.EntityType.LIGHTNING_BOLT, level);
            bolt.moveTo(pos.getX()+0.5, pos.getY(), pos.getZ()+0.5);
            level.addFreshEntity(bolt);
        }

        // Crash down
        player.setDeltaMovement(0, -5, 0);

        // Kill EVERYTHING alive — even creative mode players (except owner)
        List<LivingEntity> all = level.getEntitiesOfClass(LivingEntity.class,
            new AABB(center).inflate(200), e -> e != player);
        for (LivingEntity e : all) {
            if (e instanceof ServerPlayer sp) {
                // Force-kill even creative/god mode players
                sp.setHealth(0);
                sp.hurt(level.damageSources().playerAttack(player), Float.MAX_VALUE);
                sp.kill();
            } else {
                e.setHealth(0);
                e.hurt(level.damageSources().playerAttack(player), Float.MAX_VALUE);
                e.kill();
            }
        }

        level.getServer().getPlayerList().broadcastSystemMessage(
            Component.literal("💀 Heaven's Judgment executed! All life within 200 blocks has been erased! 💀")
                .withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
    }

    // 120% — Divine Merge
    private static void activate120(ServerPlayer player, ItemStack stack, Level level, long tick) {
        if (isCooldown(stack, TAG_COOLDOWN_120, tick)) {
            showCooldown(player, "Divine Merge", getRemainingCooldown(stack, TAG_COOLDOWN_120, tick));
            return;
        }
        setCooldown(stack, TAG_COOLDOWN_120, tick, CD_120);

        // Enter merged form
        stack.getOrCreateTag().putBoolean(TAG_MERGED, true);
        stack.getOrCreateTag().putLong(TAG_MERGE_END, tick + MERGE_DURATION);

        // Godlike stats
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, MERGE_DURATION, 100));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, MERGE_DURATION, 10));
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, MERGE_DURATION, 100));
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, MERGE_DURATION, 200));
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, MERGE_DURATION, 10));
        player.setGlowingTag(true);

        if (level instanceof ServerLevel serverLevel) {
            serverLevel.getServer().getPlayerList().broadcastSystemMessage(
                Component.literal("⚡ " + player.getName().getString() +
                    " has MERGED with the Divine Sword! ALL SHALL BE ERASED! ⚡")
                    .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
        }

        // Erase everything nearby immediately
        AABB box = player.getBoundingBox().inflate(50);
        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, box,
            e -> e != player && e.isAlive());
        for (LivingEntity e : targets) {
            e.setHealth(0);
            e.hurt(level.damageSources().playerAttack(player), Float.MAX_VALUE);
            e.kill();
        }

        player.displayClientMessage(
            Component.literal("⚡ DIVINE MERGE ACTIVATED! 30 seconds of absolute power! ⚡")
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
    }

    public static void endMergeForm(ServerPlayer player, ItemStack stack) {
        CompoundTag tag = stack.getOrCreateTag();
        tag.remove(TAG_MERGED);
        tag.remove(TAG_MERGE_END);
        tag.putLong(TAG_MERGE_WEAKNESS_END, getTick(player.level()) + CD_120);

        player.setGlowingTag(false);
        // Apply weakness
        player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, CD_120, 5));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, CD_120, 3));
        player.removeAllEffects();
        player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, CD_120, 5));

        player.displayClientMessage(
            Component.literal("💀 Divine Merge ended. You are weakened for 10 minutes.")
                .withStyle(ChatFormatting.DARK_RED), false);
    }

    // ─── Tooltip ──────────────────────────────────────────────────────────────

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);

        int power = getPowerLevel(stack);
        int stones = getStoneCount(stack);
        int bonus = getBonusDamage(stack);

        tooltip.add(Component.literal("⚡ DIVINE SWORD OF THE GODS ⚡").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        tooltip.add(Component.literal("Power: " + power + "% | Stones: " + stones + "/3").withStyle(ChatFormatting.YELLOW));
        tooltip.add(Component.literal("Base DMG: " + (20 + bonus) + " | Bonus from kills: +" + bonus).withStyle(ChatFormatting.RED));
        tooltip.add(Component.literal("Fire Immune | Fire Aspect X | Sweeping V").withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.empty());
        tooltip.add(Component.literal("[;] Activate Power | [LAlt] Switch Mode").withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.literal("[RClick] Divine Laser (5♥, 50s CD)").withStyle(ChatFormatting.LIGHT_PURPLE));

        if (hasOwner(stack)) {
            UUID owner = getOwner(stack);
            tooltip.add(Component.literal("Owner: " + owner.toString().substring(0, 8) + "...")
                .withStyle(ChatFormatting.GRAY));
        } else {
            tooltip.add(Component.literal("No owner. Use /divinesword claim to claim.").withStyle(ChatFormatting.GRAY));
        }
    }

    @Override
    public boolean isFireResistant() { return true; }

    @Override
    public boolean isFoil(ItemStack stack) { return true; } // glowing enchantment effect

    private static void showCooldown(ServerPlayer player, String ability, long remainingTicks) {
        long secs = remainingTicks / 20;
        player.displayClientMessage(
            Component.literal("⏳ " + ability + " cooldown: " + secs + "s")
                .withStyle(ChatFormatting.RED), true);
    }
}
