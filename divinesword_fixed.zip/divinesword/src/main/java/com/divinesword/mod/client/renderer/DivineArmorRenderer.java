package com.divinesword.mod.client.renderer;

import com.divinesword.mod.DivineSwordMod;
import com.divinesword.mod.item.DivineArmorItem;
import net.minecraft.client.model.HumanoidArmorModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import javax.annotation.Nonnull;

/**
 * Provides custom armor texture paths for the Divine Armor.
 * Registered via IClientItemExtensions in DivineArmorItem.
 */
public class DivineArmorRenderer implements IClientItemExtensions {

    private static final ResourceLocation LAYER_1 =
        new ResourceLocation(DivineSwordMod.MOD_ID, "textures/armor/divine_layer_1.png");
    private static final ResourceLocation LAYER_2 =
        new ResourceLocation(DivineSwordMod.MOD_ID, "textures/armor/divine_layer_2.png");

    public static final DivineArmorRenderer INSTANCE = new DivineArmorRenderer();

    @Nonnull
    public ResourceLocation getArmorTexture(ItemStack stack, LivingEntity entity,
                                             EquipmentSlot slot, String type) {
        return slot == EquipmentSlot.LEGS ? LAYER_2 : LAYER_1;
    }
}
