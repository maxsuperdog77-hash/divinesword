package com.divinesword.mod.network;

import com.divinesword.mod.DivineSwordMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModNetwork {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        new ResourceLocation(DivineSwordMod.MOD_ID, "main"),
        () -> PROTOCOL,
        PROTOCOL::equals,
        PROTOCOL::equals
    );

    private static int packetId = 0;

    public static void register() {
        CHANNEL.registerMessage(packetId++, ActivatePowerPacket.class,
            ActivatePowerPacket::encode, ActivatePowerPacket::decode, ActivatePowerPacket::handle);

        CHANNEL.registerMessage(packetId++, SwitchModePacket.class,
            SwitchModePacket::encode, SwitchModePacket::decode, SwitchModePacket::handle);

        CHANNEL.registerMessage(packetId++, BootBurnPacket.class,
            BootBurnPacket::encode, BootBurnPacket::decode, BootBurnPacket::handle);
    }
}
