package com.divinesword.mod.client;

import com.divinesword.mod.network.ActivatePowerPacket;
import com.divinesword.mod.network.BootBurnPacket;
import com.divinesword.mod.network.ModNetwork;
import com.divinesword.mod.network.SwitchModePacket;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ClientKeyHandler {

    public static KeyMapping ACTIVATE_KEY;
    public static KeyMapping SWITCH_MODE_KEY;
    public static KeyMapping BOOT_BURN_KEY;

    @Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class RegisterKeys {
        @SubscribeEvent
        public static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
            ACTIVATE_KEY = new KeyMapping("key.divinesword.activate",
                InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_SEMICOLON, "key.categories.divinesword");
            SWITCH_MODE_KEY = new KeyMapping("key.divinesword.switchmode",
                InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_ALT, "key.categories.divinesword");
            BOOT_BURN_KEY = new KeyMapping("key.divinesword.bootburn",
                InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_N, "key.categories.divinesword");

            event.register(ACTIVATE_KEY);
            event.register(SWITCH_MODE_KEY);
            event.register(BOOT_BURN_KEY);
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        while (ACTIVATE_KEY != null && ACTIVATE_KEY.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new ActivatePowerPacket());
        }
        while (SWITCH_MODE_KEY != null && SWITCH_MODE_KEY.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new SwitchModePacket());
        }
        while (BOOT_BURN_KEY != null && BOOT_BURN_KEY.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new BootBurnPacket());
        }
    }
}
