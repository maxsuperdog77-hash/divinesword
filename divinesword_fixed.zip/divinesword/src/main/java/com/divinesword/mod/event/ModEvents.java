package com.divinesword.mod.event;

import com.divinesword.mod.item.DivineArmorItem;
import com.divinesword.mod.item.DivineSwordItem;
import com.divinesword.mod.item.ModItems;
import com.divinesword.mod.network.ModNetwork;
import com.divinesword.mod.util.DivineSwordEffects;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber
public class ModEvents {

    // Track consecutive hits per attacker-target pair
    private static final Map<String, Integer> hitTracker = new HashMap<>();

    // ─── Player Tick ──────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Player player = event.player;

        ItemStack mainHand = player.getMainHandItem();
        boolean holdingSword = mainHand.getItem() instanceof DivineSwordItem;

        if (holdingSword) {
            applyWielderPassives(player, mainHand);
        }

        // Armor tick
        for (ItemStack armor : player.getArmorSlots()) {
            if (armor.getItem() instanceof DivineArmorItem divineArmor) {
                divineArmor.onArmorTick(armor, player.level(), player);
            }
        }

        // Server only: check divine merge end, heaven's judgment, particles
        if (!player.level().isClientSide && player instanceof ServerPlayer sp) {
            checkMergeEnd(sp, mainHand);
            checkHeavensJudgment(sp, mainHand);
            checkArmorEvolveExpiry(sp);

            // Visual effects every 5 ticks
            if (player.level().getGameTime() % 5 == 0 && player.level() instanceof ServerLevel sl) {
                if (holdingSword && DivineSwordItem.isOwner(mainHand, player)) {
                    int power = DivineSwordItem.getPowerLevel(mainHand);
                    DivineSwordEffects.spawnWielderAura(player, sl, power);
                    DivineSwordEffects.spawnHolySun(player, sl);
                    DivineSwordEffects.spawnLightningSparks(player, sl);
                    DivineSwordEffects.spawnStoneWave(player, sl);
                }
            }
        }

        // N key boot burn check is handled client-side via key binding (see KeyHandler)
    }

    private static void applyWielderPassives(Player player, ItemStack sword) {
        if (!DivineSwordItem.isOwner(sword, player)) return;

        // Fire immunity
        player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 40, 10, false, false));

        // Glowing aura (glow)
        player.setGlowingTag(true);

        // Passive protection approximation via resistance
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 1, false, false));
    }

    private static void checkMergeEnd(ServerPlayer player, ItemStack sword) {
        if (!(sword.getItem() instanceof DivineSwordItem)) return;
        var tag = sword.getOrCreateTag();
        if (!tag.getBoolean(DivineSwordItem.TAG_MERGED)) return;

        long tick = player.level().getGameTime();
        long mergeEnd = tag.getLong(DivineSwordItem.TAG_MERGE_END);

        if (tick >= mergeEnd) {
            DivineSwordItem.endMergeForm(player, sword);
        } else {
            // Continue erasing nearby entities
            AABB box = player.getBoundingBox().inflate(30);
            List<LivingEntity> targets = player.level().getEntitiesOfClass(LivingEntity.class, box,
                e -> e != player && e.isAlive());
            for (LivingEntity e : targets) {
                e.setHealth(0);
                e.hurt(player.level().damageSources().playerAttack(player), Float.MAX_VALUE);
                e.kill();
            }
        }
    }

    private static void checkHeavensJudgment(ServerPlayer player, ItemStack sword) {
        if (!(sword.getItem() instanceof DivineSwordItem)) return;
        var tag = sword.getOrCreateTag();
        if (!tag.getBoolean("HeavenJudgmentPending")) return;

        long tick = player.level().getGameTime();
        long judgmentTick = tag.getLong("HeavenJudgmentTick");

        if (tick >= judgmentTick && player.level() instanceof ServerLevel sl) {
            DivineSwordItem.executeHeavensJudgment(player, sword, sl);
        }
    }

    // ─── Attack event — bonus damage and kill tracking ─────────────────────

    @SubscribeEvent
    public static void onAttack(AttackEntityEvent event) {
        Player player = event.getEntity();
        ItemStack sword = player.getMainHandItem();
        if (!(sword.getItem() instanceof DivineSwordItem)) return;
        if (!DivineSwordItem.isOwner(sword, player)) return;

        String key = player.getUUID() + "-" + event.getTarget().getUUID();
        hitTracker.merge(key, 1, Integer::sum);
    }

    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        if (!(event.getSource().getEntity() instanceof Player player)) return;
        ItemStack sword = player.getMainHandItem();
        if (!(sword.getItem() instanceof DivineSwordItem)) return;

        // Apply bonus damage from kills
        int bonus = DivineSwordItem.getBonusDamage(sword);
        event.setAmount(event.getAmount() + bonus);
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (!(event.getSource().getEntity() instanceof Player player)) return;
        ItemStack sword = player.getMainHandItem();
        if (!(sword.getItem() instanceof DivineSwordItem)) return;

        String key = player.getUUID() + "-" + event.getEntity().getUUID();
        int hits = hitTracker.getOrDefault(key, 1);
        hitTracker.remove(key);

        ((DivineSwordItem) sword.getItem()).recordKill(sword, hits);
    }

    // ─── Damage immunity for divine armor ────────────────────────────────────

    @SubscribeEvent
    public static void onLivingDamage(LivingDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!hasDivineArmor(player)) return;

        // Cancel all damage if wearing full divine set
        if (hasFullDivineArmor(player)) {
            event.setCanceled(true);
        }
    }

    private static boolean hasDivineArmor(Player player) {
        for (ItemStack a : player.getArmorSlots()) {
            if (a.getItem() instanceof DivineArmorItem) return true;
        }
        return false;
    }

    private static boolean hasFullDivineArmor(Player player) {
        int count = 0;
        for (ItemStack a : player.getArmorSlots()) {
            if (a.getItem() instanceof DivineArmorItem da && DivineArmorItem.isDivine(a)) count++;
        }
        return count >= 4;
    }

    // ─── Chat events ─────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onChat(ServerChatEvent event) {
        ServerPlayer player = event.getPlayer();
        String msg = event.getRawText().trim();

        // "611" — evolve armor temporarily
        if (msg.equals("611")) {
            event.setCanceled(true);
            handleArmorEvolve(player);
            return;
        }

        // "Mada" — give Adam's Milk
        if (msg.equalsIgnoreCase("Mada")) {
            event.setCanceled(true);
            giveAdamsMilk(player);
            return;
        }

        // ";" key chat trigger from network packet is handled separately
    }

    private static void handleArmorEvolve(ServerPlayer player) {
        // Check cooldown
        long tick = player.level().getGameTime();
        var persistData = player.getPersistentData();
        long cdEnd = persistData.getLong("ArmorEvolveCooldown");

        if (tick < cdEnd) {
            long rem = (cdEnd - tick) / 20;
            player.displayClientMessage(
                Component.literal("⏳ Armor evolve cooldown: " + rem + "s")
                    .withStyle(ChatFormatting.RED), false);
            return;
        }

        // Evolve all armor for 1 minute
        for (ItemStack armor : player.getArmorSlots()) {
            if (armor.getItem() instanceof DivineArmorItem) {
                DivineArmorItem.setDivine(armor, true);
            }
        }

        persistData.putLong("ArmorEvolveCooldown", tick + 3 * 60 * 20);
        persistData.putLong("ArmorEvolveEnd", tick + 60 * 20);

        player.displayClientMessage(
            Component.literal("✦ 611 ACTIVATED! Divine Armor evolved for 1 minute! ✦")
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
    }

    public static void checkArmorEvolveExpiry(ServerPlayer player) {
        long tick = player.level().getGameTime();
        var data = player.getPersistentData();
        long evolveEnd = data.getLong("ArmorEvolveEnd");

        if (evolveEnd > 0 && tick >= evolveEnd) {
            data.putLong("ArmorEvolveEnd", 0);
            // Revert non-permanent divine armor
            for (ItemStack armor : player.getArmorSlots()) {
                if (armor.getItem() instanceof DivineArmorItem) {
                    // Only revert if not permanently evolved (no Adams Milk tag)
                    if (!armor.getOrCreateTag().getBoolean("PermanentDivine")) {
                        DivineArmorItem.setDivine(armor, false);
                    }
                }
            }
            player.displayClientMessage(
                Component.literal("✦ Divine Armor has reverted to normal form. ✦")
                    .withStyle(ChatFormatting.YELLOW), false);
        }
    }

    private static void giveAdamsMilk(ServerPlayer player) {
        ItemStack milk = new ItemStack(ModItems.ADAMS_MILK.get(), 1);
        player.getInventory().add(milk);
        player.displayClientMessage(
            Component.literal("✦ Adam has granted you his sacred milk! ✦")
                .withStyle(ChatFormatting.GOLD), false);
    }
}
