package com.divinesword.mod.network;

import com.divinesword.mod.item.DivineSwordItem;
import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SwitchModePacket {

    public SwitchModePacket() {}

    public static void encode(SwitchModePacket msg, FriendlyByteBuf buf) {}
    public static SwitchModePacket decode(FriendlyByteBuf buf) { return new SwitchModePacket(); }

    public static void handle(SwitchModePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;

            ItemStack sword = player.getMainHandItem();
            if (!(sword.getItem() instanceof DivineSwordItem)) return;
            if (!DivineSwordItem.isOwner(sword, player)) return;

            var tag = sword.getOrCreateTag();
            int mode = tag.getInt(DivineSwordItem.TAG_MODE);
            mode = (mode + 1) % 2;
            tag.putInt(DivineSwordItem.TAG_MODE, mode);

            String modeName = mode == 0 ? "Normal Mode" : "Divine Mode";
            player.displayClientMessage(
                Component.literal("⚔ Switched to: " + modeName)
                    .withStyle(ChatFormatting.GOLD), true);
        });
        ctx.get().setPacketHandled(true);
    }
}
