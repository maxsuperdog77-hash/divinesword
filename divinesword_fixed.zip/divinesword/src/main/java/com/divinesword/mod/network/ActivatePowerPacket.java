package com.divinesword.mod.network;

import com.divinesword.mod.item.DivineSwordItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class ActivatePowerPacket {

    public ActivatePowerPacket() {}

    public static void encode(ActivatePowerPacket msg, FriendlyByteBuf buf) {}

    public static ActivatePowerPacket decode(FriendlyByteBuf buf) {
        return new ActivatePowerPacket();
    }

    public static void handle(ActivatePowerPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;

            ItemStack sword = player.getMainHandItem();
            if (sword.getItem() instanceof DivineSwordItem) {
                DivineSwordItem.activatePower(player, sword);
            } else {
                // Check if in inventory (summon to hand)
                for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
                    ItemStack slot = player.getInventory().getItem(i);
                    if (slot.getItem() instanceof DivineSwordItem) {
                        if (DivineSwordItem.isOwner(slot, player)) {
                            // Move to main hand
                            player.getInventory().selected = i < 9 ? i : 0;
                        }
                        break;
                    }
                }
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
