package com.divinesword.mod.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

public class PowerStoneItem extends Item {
    private final int stoneIndex;

    public PowerStoneItem(int index) {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.RARE).fireResistant());
        this.stoneIndex = index;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stoneStack = player.getItemInHand(hand);

        // Find divine sword in inventory
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack slot = player.getInventory().getItem(i);
            if (slot.getItem() instanceof DivineSwordItem) {
                if (DivineSwordItem.insertStone(slot, stoneIndex)) {
                    stoneStack.shrink(1);
                    if (!level.isClientSide) {
                        int power = DivineSwordItem.getPowerLevel(slot);
                        player.displayClientMessage(
                            Component.literal("✦ Stone " + stoneIndex + " embedded! Power: " + power + "% ✦")
                                .withStyle(ChatFormatting.GOLD), true);
                    }
                    return InteractionResultHolder.success(stoneStack);
                } else {
                    if (!level.isClientSide) {
                        player.displayClientMessage(
                            Component.literal("✦ Stone " + stoneIndex + " already embedded! ✦")
                                .withStyle(ChatFormatting.RED), true);
                    }
                    return InteractionResultHolder.fail(stoneStack);
                }
            }
        }

        if (!level.isClientSide) {
            player.displayClientMessage(
                Component.literal("✦ No Divine Sword found in inventory! ✦")
                    .withStyle(ChatFormatting.RED), true);
        }
        return InteractionResultHolder.fail(stoneStack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        String[] names = {"First", "Second", "Third"};
        String[] powers = {"50%", "75%", "100%"};
        tooltip.add(Component.literal("⬡ Power Stone " + stoneIndex + " (" + names[stoneIndex-1] + ")")
            .withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.literal("Unlocks " + powers[stoneIndex-1] + " power when inserted into the Divine Sword")
            .withStyle(ChatFormatting.YELLOW));
        tooltip.add(Component.literal("Right-click to insert into Divine Sword in inventory")
            .withStyle(ChatFormatting.GRAY));
    }
}
