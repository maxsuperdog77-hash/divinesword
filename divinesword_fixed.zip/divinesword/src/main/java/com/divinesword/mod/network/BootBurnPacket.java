package com.divinesword.mod.network;

import com.divinesword.mod.item.DivineArmorItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.network.NetworkEvent;

import java.util.List;
import java.util.function.Supplier;

public class BootBurnPacket {
    public BootBurnPacket() {}
    public static void encode(BootBurnPacket msg, FriendlyByteBuf buf) {}
    public static BootBurnPacket decode(FriendlyByteBuf buf) { return new BootBurnPacket(); }

    public static void handle(BootBurnPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;

            ItemStack boots = player.getItemBySlot(EquipmentSlot.FEET);
            if (!(boots.getItem() instanceof DivineArmorItem) || !DivineArmorItem.isDivine(boots)) return;

            // Burn all entities in a 5-block radius
            AABB box = player.getBoundingBox().inflate(5);
            List<LivingEntity> targets = player.level().getEntitiesOfClass(LivingEntity.class, box,
                e -> e != player && e.isAlive());
            for (LivingEntity e : targets) {
                e.setSecondsOnFire(8);
                e.hurt(player.level().damageSources().playerAttack(player), 8f);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
