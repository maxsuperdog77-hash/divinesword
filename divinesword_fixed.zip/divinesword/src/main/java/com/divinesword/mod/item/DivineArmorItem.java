package com.divinesword.mod.item;

import com.divinesword.mod.armor.ModArmorMaterials;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

public class DivineArmorItem extends ArmorItem {

    public static final String TAG_DIVINE = "IsDivine";

    public DivineArmorItem(ArmorItem.Type type) {
        super(ModArmorMaterials.DIVINE, type, new Properties()
            .stacksTo(1)
            .rarity(Rarity.EPIC)
            .fireResistant());
    }

    public static boolean isDivine(ItemStack stack) {
        return stack.getOrCreateTag().getBoolean(TAG_DIVINE);
    }

    public static void setDivine(ItemStack stack, boolean divine) {
        stack.getOrCreateTag().putBoolean(TAG_DIVINE, divine);
    }

    @Override
    public void onArmorTick(ItemStack stack, Level level, Player player) {
        if (isDivine(stack)) {
            applyDivineEffects(player, stack);
        } else {
            applyNormalEffects(player, stack);
        }
    }

    private void applyNormalEffects(Player player, ItemStack stack) {
        player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 40, 0, false, false));
    }

    private void applyDivineEffects(Player player, ItemStack stack) {
        player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 40, 10, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 40, 200, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 10, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.LUCK, 40, 10, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 40, 5, false, false));

        if (this.getType() == ArmorItem.Type.CHESTPLATE) {
            player.getAbilities().mayfly = true;
            player.onUpdateAbilities();
        }

        if (this.getType() == ArmorItem.Type.BOOTS) {
            player.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 40, 5, false, false));
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);
        boolean divine = isDivine(stack);
        tooltip.add(Component.literal(divine ? "✦ DIVINE FORM ✦" : "✦ NORMAL FORM ✦")
            .withStyle(divine ? ChatFormatting.GOLD : ChatFormatting.WHITE, ChatFormatting.BOLD));
        if (divine) {
            tooltip.add(Component.literal("999+ Armor | 5000+ HP | Full immunity").withStyle(ChatFormatting.YELLOW));
            if (getType() == ArmorItem.Type.CHESTPLATE)
                tooltip.add(Component.literal("✦ Holy flame wings — FLIGHT enabled").withStyle(ChatFormatting.AQUA));
            if (getType() == ArmorItem.Type.HELMET)
                tooltip.add(Component.literal("✦ Glowing divine crown").withStyle(ChatFormatting.YELLOW));
            if (getType() == ArmorItem.Type.BOOTS)
                tooltip.add(Component.literal("✦ Water walking | Fast swimming | [N] Burns enemies").withStyle(ChatFormatting.AQUA));
        }
        tooltip.add(Component.literal("Type '611' in chat to evolve (1min, 3min CD)").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("Or drink Adam's Milk for permanent divine form").withStyle(ChatFormatting.GRAY));
    }
}
