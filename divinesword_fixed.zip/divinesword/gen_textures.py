#!/usr/bin/env python3
"""
Generate all Divine Sword mod textures as 16x16 (or 64x64 for armor) PNGs.
Colors: black, gold, red, orange, with holy yellow-white flame accents.
"""
from PIL import Image, ImageDraw
import os, math

BASE = "/home/claude/divinesword/src/main/resources/assets/divinesword/textures"
ITEM = f"{BASE}/item"
ARMOR = f"{BASE}/armor"

# ── Palette ──────────────────────────────────────────────────────────────────
BLACK      = (10,  8, 12, 255)
DARK       = (25, 20, 30, 255)
GOLD       = (212, 175, 55, 255)
GOLD2      = (255, 215, 0, 255)
ORANGE     = (220, 100, 20, 255)
ORANGE2    = (255, 140, 0, 255)
RED        = (180, 20, 20, 255)
RED2       = (220, 50, 50, 255)
FIRE_Y     = (255, 240, 80, 255)   # holy yellow fire
FIRE_W     = (255, 255, 200, 255)  # bright white flame core
TRANS      = (0, 0, 0, 0)
STONE_GREY = (140, 130, 120, 255)
STONE_LIT  = (200, 180, 100, 255)
SILVER     = (180, 180, 200, 255)

def px(img, x, y, c):
    if 0 <= x < img.width and 0 <= y < img.height:
        img.putpixel((x, y), c)

# ── Divine Sword (16x16) ────────────────────────────────────────────────────
def make_divine_sword():
    img = Image.new("RGBA", (16, 16), TRANS)

    # Blade (center-right diagonal, thick)
    blade = [
        (14, 0), (13, 0),                          # tip
        (13, 1), (12, 1),
        (12, 2), (11, 2),
        (11, 3), (10, 3),
        (10, 4), (9,  4),
        (9,  5), (8,  5),
        (8,  6), (7,  6),
        (7,  7), (6,  7),
    ]
    for (x,y) in blade:
        px(img, x, y, GOLD2)

    # Blade center stripe (orange-red holy fire)
    blade_center = [(13,1),(12,2),(11,3),(10,4),(9,5),(8,6),(7,7)]
    for (x,y) in blade_center:
        px(img, x, y, FIRE_Y)

    # Blade edge glow
    glow = [(14,0),(13,0),(12,1),(11,2),(10,3),(9,4),(8,5),(7,6)]
    for (x,y) in glow:
        px(img, x, y, FIRE_W)

    # Three embedded stones
    px(img, 6, 8, STONE_LIT)   # stone near handle
    px(img, 9, 5, RED2)         # middle stone
    px(img, 12, 2, RED)         # tip stone

    # Cross-guard (black with gold trim)
    guard = [(5,8),(5,9),(6,8),(6,9),(7,8),(7,9),(4,8),(4,9)]
    for (x,y) in guard:
        px(img, x, y, BLACK)
    # Gold trim on guard
    for (x,y) in [(5,7),(6,7),(7,7),(4,8)]:
        px(img, x, y, GOLD)

    # Fire reserves (left and right of guard)
    fire_L = [(3,7),(3,8),(3,9),(2,8)]
    fire_R = [(8,7),(8,8),(9,7)]
    for (x,y) in fire_L:
        px(img, x, y, ORANGE2)
    px(img, 2, 7, FIRE_Y)
    for (x,y) in fire_R:
        px(img, x, y, ORANGE)
    px(img, 8, 6, FIRE_Y)

    # Handle (black with red/gold/orange stripes)
    handle = [(5,10),(5,11),(5,12),(5,13),(5,14),(5,15),
              (6,10),(6,11),(6,12),(6,13),(6,14),(6,15)]
    for (x,y) in handle:
        px(img, x, y, BLACK)
    # Stripes
    for y in [10, 12, 14]:
        px(img, 5, y, RED)
        px(img, 6, y, GOLD)
    for y in [11, 13, 15]:
        px(img, 5, y, ORANGE)
        px(img, 6, y, RED2)

    # Pommel
    for (x,y) in [(4,15),(5,15),(6,15),(7,15),(4,14),(7,14)]:
        px(img, x, y, GOLD2)
    px(img, 5, 15, RED)
    px(img, 6, 15, RED)

    return img

# ── Power Stones (16x16) ────────────────────────────────────────────────────
def make_stone(index):
    img = Image.new("RGBA", (16, 16), TRANS)
    colors = [
        (RED, RED2, FIRE_Y),
        (ORANGE, ORANGE2, GOLD2),
        (GOLD, GOLD2, FIRE_W),
    ]
    c1, c2, glow = colors[index - 1]

    # Hexagonal gem shape
    gem = [
        (7,1),(8,1),
        (5,2),(6,2),(7,2),(8,2),(9,2),(10,2),
        (4,3),(5,3),(6,3),(7,3),(8,3),(9,3),(10,3),(11,3),
        (4,4),(5,4),(6,4),(7,4),(8,4),(9,4),(10,4),(11,4),
        (4,5),(5,5),(6,5),(7,5),(8,5),(9,5),(10,5),(11,5),
        (5,6),(6,6),(7,6),(8,6),(9,6),(10,6),
        (6,7),(7,7),(8,7),(9,7),
        (7,8),(8,8),
    ]
    for (x,y) in gem:
        px(img, x, y, c1)
    # Inner highlight
    for (x,y) in [(7,3),(8,3),(6,4),(7,4),(8,4),(9,4)]:
        px(img, x, y, glow)
    # Outline
    for (x,y) in [(7,1),(8,1),(4,3),(11,3),(4,5),(11,5),(6,7),(9,7),(7,8),(8,8)]:
        px(img, x, y, c2)

    # Roman numeral dots
    for i in range(index):
        px(img, 6+i*2, 9, BLACK)

    return img

# ── Adam's Milk (16x16) ─────────────────────────────────────────────────────
def make_adams_milk():
    img = Image.new("RGBA", (16, 16), TRANS)
    # Bottle outline
    bottle = [
        (6,1),(7,1),(8,1),(9,1),
        (6,2),(9,2),
        (5,3),(6,3),(9,3),(10,3),
        (4,4),(5,4),(6,4),(7,4),(8,4),(9,4),(10,4),(11,4),
        (4,5),(11,5),(4,6),(11,6),(4,7),(11,7),
        (4,8),(11,8),(4,9),(11,9),(4,10),(11,10),
        (4,11),(5,11),(6,11),(7,11),(8,11),(9,11),(10,11),(11,11),
        (5,12),(6,12),(7,12),(8,12),(9,12),(10,12),
    ]
    for (x,y) in bottle:
        px(img, x, y, GOLD)
    # Milk fill (glowing white-gold)
    for y in range(5, 11):
        for x in range(5, 11):
            px(img, x, y, FIRE_W)
    # Gold shimmer on milk
    for (x,y) in [(6,6),(8,6),(7,7),(5,8),(9,8),(7,9)]:
        px(img, x, y, GOLD2)
    # Cork
    for (x,y) in [(7,0),(8,0),(7,1),(8,1)]:
        px(img, x, y, ORANGE)
    return img

# ── Armor textures (64x32 sheet format) ─────────────────────────────────────
def make_armor_layer(layer_num):
    """
    layer_1.png = helmet + chestplate + boots
    layer_2.png = leggings
    Both are 64x32 pixels following vanilla UV layout.
    """
    img = Image.new("RGBA", (64, 32), TRANS)
    draw = ImageDraw.Draw(img)

    def fill_rect(x, y, w, h, color):
        for dy in range(h):
            for dx in range(w):
                px(img, x+dx, y+dy, color)

    def outline_rect(x, y, w, h, color):
        for dx in range(w):
            px(img, x+dx, y, color)
            px(img, x+dx, y+h-1, color)
        for dy in range(h):
            px(img, x, y+dy, color)
            px(img, x+w-1, y+dy, color)

    if layer_num == 1:
        # ── HELMET (8x8 head, UV at 0,0) ──
        fill_rect(0, 0, 32, 16, BLACK)
        # Face plate
        fill_rect(8, 8, 8, 8, DARK)
        fill_rect(9, 9, 6, 5, GOLD)
        # Crown spikes
        for i in range(4):
            px(img, 9+i*2, 0, FIRE_Y)
            px(img, 9+i*2, 1, GOLD2)
        # Eye slits
        for x in range(10, 13): px(img, x, 11, RED2)
        for x in range(10, 13): px(img, x, 12, ORANGE2)
        # Gold trim outline
        outline_rect(8, 8, 8, 8, GOLD2)

        # ── CHESTPLATE (UV at 16,16 for body) ──
        fill_rect(16, 16, 24, 12, BLACK)
        # Gold pattern on chest
        for x in range(17, 39):
            px(img, x, 17, GOLD)
            px(img, x, 27, GOLD)
        # Red gem center
        fill_rect(26, 19, 4, 4, RED)
        px(img, 27, 20, RED2)
        px(img, 28, 20, RED2)
        # Orange/gold flame wings pattern
        for y in range(18, 27):
            px(img, 16, y, ORANGE2)
            px(img, 39, y, ORANGE2)
        for i in range(4):
            px(img, 17+i, 18+i, FIRE_Y)
            px(img, 38-i, 18+i, FIRE_Y)
        # Divine cross
        for y in range(18, 27): px(img, 28, y, GOLD2)
        for x in range(20, 36): px(img, x, 22, GOLD2)

        # ── BOOTS (UV at 0,16) ──
        fill_rect(0, 16, 16, 12, BLACK)
        for x in range(0, 16): px(img, x, 16, GOLD)
        for x in range(0, 16): px(img, x, 27, ORANGE)
        for y in range(16, 28):
            px(img, 0, y, GOLD)
            px(img, 15, y, GOLD)
        # Flame pattern on boots
        for i in range(5):
            px(img, 3+i, 18+i//2, FIRE_Y)
            px(img, 12-i, 18+i//2, FIRE_Y)
        # Red stripe
        for x in range(1, 15): px(img, x, 24, RED)

    else:
        # ── LEGGINGS (layer 2, UV at 0,0 for left leg, 16,0 for right) ──
        fill_rect(0, 0, 32, 12, BLACK)
        # Gold stripe down each leg
        for y in range(0, 12):
            px(img, 4, y, GOLD)
            px(img, 11, y, GOLD)
            px(img, 20, y, GOLD)
            px(img, 27, y, GOLD)
        # Orange accent
        for x in range(0, 12):
            px(img, x, 0, ORANGE)
            px(img, x+16, 0, ORANGE)
        # Red stripes across
        for x in range(1, 11): px(img, x, 4, RED)
        for x in range(1, 11): px(img, x, 8, RED)
        for x in range(17, 27): px(img, x, 4, RED)
        for x in range(17, 27): px(img, x, 8, RED)
        # Flame rune marks
        px(img, 6, 2, FIRE_Y); px(img, 7, 2, FIRE_Y)
        px(img, 6, 6, FIRE_Y); px(img, 7, 6, FIRE_Y)
        px(img, 22, 2, FIRE_Y); px(img, 23, 2, FIRE_Y)
        px(img, 22, 6, FIRE_Y); px(img, 23, 6, FIRE_Y)

    return img

# ── Helmet item icon ─────────────────────────────────────────────────────────
def make_armor_item(slot):
    img = Image.new("RGBA", (16, 16), TRANS)
    if slot == "helmet":
        # Crown shape
        for x in range(3, 13): px(img, x, 8, GOLD)
        for x in range(3, 13): px(img, x, 9, BLACK)
        for x in range(3, 13): px(img, x, 10, BLACK)
        for x in range(3, 13): px(img, x, 11, GOLD)
        # Crown spikes
        for (x,y,c) in [(4,6,FIRE_Y),(6,5,FIRE_W),(8,4,GOLD2),(10,5,FIRE_W),(12,6,FIRE_Y)]:
            px(img, x, y, c)
            px(img, x, y+1, GOLD)
        # Eye gems
        px(img, 6, 9, RED); px(img, 9, 9, RED)
    elif slot == "chestplate":
        for x in range(2, 14): px(img, x, 3, GOLD)
        for y in range(3, 14):
            for x in range(2, 14):
                px(img, x, y, BLACK)
        # Red center gem
        for (x,y) in [(7,6),(8,6),(7,7),(8,7)]: px(img, x, y, RED2)
        # Wing flame hints
        for i in range(4):
            px(img, 2+i, 5+i, ORANGE2)
            px(img, 13-i, 5+i, ORANGE2)
        # Gold cross
        for y in range(4, 13): px(img, 7, y, GOLD)
        for x in range(3, 12): px(img, x, 7, GOLD)
        # Outline
        for x in range(2,14): px(img, x, 3, GOLD2); px(img, x, 13, GOLD2)
        for y in range(3,14): px(img, 2, y, GOLD2); px(img, 13, y, GOLD2)
    elif slot == "leggings":
        # Two legs
        for y in range(2, 14):
            for x in range(2, 7): px(img, x, y, BLACK)
            for x in range(9, 14): px(img, x, y, BLACK)
        for x in range(2, 14): px(img, x, 2, GOLD)
        for y in range(2, 8):
            px(img, 4, y, GOLD); px(img, 11, y, GOLD)
        for x in range(2, 7): px(img, x, 5, RED)
        for x in range(9, 14): px(img, x, 5, RED)
        for x in range(2, 7): px(img, x, 9, ORANGE)
        for x in range(9, 14): px(img, x, 9, ORANGE)
    elif slot == "boots":
        for y in range(5, 14):
            for x in range(3, 13): px(img, x, y, BLACK)
        for x in range(3, 13): px(img, x, 5, GOLD)
        for x in range(3, 13): px(img, x, 13, GOLD)
        for y in range(5, 14):
            px(img, 3, y, GOLD); px(img, 12, y, GOLD)
        for x in range(3, 13): px(img, x, 10, RED)
        for (x,y) in [(5,7),(6,6),(7,6),(8,7),(9,7)]: px(img, x, y, FIRE_Y)
    return img

# ── Save all textures ─────────────────────────────────────────────────────────
os.makedirs(ITEM, exist_ok=True)
os.makedirs(ARMOR, exist_ok=True)

make_divine_sword().save(f"{ITEM}/divine_sword.png")
print("✓ divine_sword.png")

for i in range(1, 4):
    make_stone(i).save(f"{ITEM}/power_stone_{i}.png")
    print(f"✓ power_stone_{i}.png")

make_adams_milk().save(f"{ITEM}/adams_milk.png")
print("✓ adams_milk.png")

for slot in ["helmet", "chestplate", "leggings", "boots"]:
    make_armor_item(slot).save(f"{ITEM}/divine_{slot}.png")
    print(f"✓ divine_{slot}.png")

make_armor_layer(1).save(f"{ARMOR}/divine_layer_1.png")
print("✓ divine_layer_1.png (helmet+chest+boots sheet)")

make_armor_layer(2).save(f"{ARMOR}/divine_layer_2.png")
print("✓ divine_layer_2.png (leggings sheet)")

print("\nAll textures generated!")
