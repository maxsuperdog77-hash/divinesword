package com.divinesword.mod.client;

import com.divinesword.mod.DivineSwordMod;
import net.minecraft.client.model.HumanoidArmorModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = DivineSwordMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    public static final ModelLayerLocation DIVINE_ARMOR_LAYER =
        new ModelLayerLocation(new ResourceLocation(DivineSwordMod.MOD_ID, "divine_armor"), "main");

    @SubscribeEvent
    public static void onRegisterLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(DIVINE_ARMOR_LAYER,
            () -> LayerDefinition.create(HumanoidArmorModel.createBodyLayer(new CubeDeformation(1.0f)), 64, 32));
    }
}
