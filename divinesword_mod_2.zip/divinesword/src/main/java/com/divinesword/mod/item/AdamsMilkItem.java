package com.divinesword.mod.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

public class AdamsMilkItem extends Item {

    public AdamsMilkItem() {
        super(new Item.Properties()
            .stacksTo(16)
            .rarity(Rarity.EPIC)
            .food(new FoodProperties.Builder()
                .nutrition(10)
                .saturationMod(2f)
                .alwaysEat()
                .build()));
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide && entity instanceof Player player) {
            // Permanently evolve all divine armor pieces
            for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
                ItemStack slot = player.getInventory().getItem(i);
                if (slot.getItem() instanceof DivineArmorItem) {
                    DivineArmorItem.setDivine(slot, true);
                }
            }
            // Also check equipped armor slots
            for (ItemStack armor : player.getArmorSlots()) {
                if (armor.getItem() instanceof DivineArmorItem) {
                    DivineArmorItem.setDivine(armor, true);
                }
            }
            player.displayClientMessage(
                Component.literal("✦ Adam's Milk consumed! Your armor is now permanently DIVINE! ✦")
                    .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
        }
        return super.finishUsingItem(stack, level, entity);
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) { return UseAnim.DRINK; }

    @Override
    public SoundEvent getDrinkingSound() { return SoundEvents.HONEY_DRINK; }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("✦ Adam's Milk ✦").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        tooltip.add(Component.literal("Permanently evolves all Divine Armor to divine form").withStyle(ChatFormatting.YELLOW));
        tooltip.add(Component.literal("Obtain by giving Adam 611 diamonds").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("or by saying the code word: Mada").withStyle(ChatFormatting.GRAY));
    }
}
