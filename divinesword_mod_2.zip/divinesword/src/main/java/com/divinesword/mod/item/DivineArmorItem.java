package com.divinesword.mod.item;

import com.divinesword.mod.armor.ModArmorMaterials;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

public class DivineArmorItem extends ArmorItem {

    public static final String TAG_DIVINE = "IsDivine";

    public DivineArmorItem(EquipmentSlot slot) {
        super(ModArmorMaterials.DIVINE, slot, new Properties()
            .stacksTo(1)
            .rarity(Rarity.EPIC)
            .fireResistant());
    }

    public static boolean isDivine(ItemStack stack) {
        return stack.getOrCreateTag().getBoolean(TAG_DIVINE);
    }

    public static void setDivine(ItemStack stack, boolean divine) {
        stack.getOrCreateTag().putBoolean(TAG_DIVINE, divine);
    }

    /** Called every tick while worn — applies passive effects */
    public void onArmorTick(ItemStack stack, Level level, Player player) {
        if (isDivine(stack)) {
            applyDivineEffects(player, stack);
        } else {
            applyNormalEffects(player, stack);
        }
    }

    private void applyNormalEffects(Player player, ItemStack stack) {
        // Normal version: netherite-tier passive bonuses
        player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 40, 0, false, false));
    }

    private void applyDivineEffects(Player player, ItemStack stack) {
        // Full immunity to fire
        player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 40, 10, false, false));
        // 5000+ health via Absorption
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 40, 200, false, false));
        // Damage immunity approximation
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 10, false, false));
        // Luck
        player.addEffect(new MobEffectInstance(MobEffects.LUCK, 40, 10, false, false));
        // Regeneration
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 40, 5, false, false));

        // Chestplate: Flight ability
        if (this.getEquipmentSlot() == EquipmentSlot.CHEST) {
            player.getAbilities().mayfly = true;
            player.onUpdateAbilities();
        }

        // Boots: Water walking via slow falling + dolphin's grace
        if (this.getEquipmentSlot() == EquipmentSlot.FEET) {
            player.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 40, 5, false, false));
            // Water walking handled in event bus
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);
        boolean divine = isDivine(stack);
        tooltip.add(Component.literal(divine ? "✦ DIVINE FORM ✦" : "✦ NORMAL FORM ✦")
            .withStyle(divine ? ChatFormatting.GOLD : ChatFormatting.WHITE, ChatFormatting.BOLD));
        if (divine) {
            tooltip.add(Component.literal("999+ Armor | 5000+ HP | Full immunity").withStyle(ChatFormatting.YELLOW));
            if (getEquipmentSlot() == EquipmentSlot.CHEST)
                tooltip.add(Component.literal("✦ Holy flame wings — FLIGHT enabled").withStyle(ChatFormatting.AQUA));
            if (getEquipmentSlot() == EquipmentSlot.HEAD)
                tooltip.add(Component.literal("✦ Glowing divine crown").withStyle(ChatFormatting.YELLOW));
            if (getEquipmentSlot() == EquipmentSlot.FEET)
                tooltip.add(Component.literal("✦ Water walking | Fast swimming | [N] Burns enemies").withStyle(ChatFormatting.AQUA));
        }
        tooltip.add(Component.literal("Type '611' in chat to evolve (1min, 3min CD)").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("Or drink Adam's Milk for permanent divine form").withStyle(ChatFormatting.GRAY));
    }
}
