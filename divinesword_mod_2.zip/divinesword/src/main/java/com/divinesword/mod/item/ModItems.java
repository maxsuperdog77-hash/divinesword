package com.divinesword.mod.item;

import com.divinesword.mod.DivineSwordMod;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
        DeferredRegister.create(ForgeRegistries.ITEMS, DivineSwordMod.MOD_ID);

    // The Divine Sword
    public static final RegistryObject<DivineSwordItem> DIVINE_SWORD =
        ITEMS.register("divine_sword", DivineSwordItem::new);

    // Power Stones
    public static final RegistryObject<PowerStoneItem> POWER_STONE_1 =
        ITEMS.register("power_stone_1", () -> new PowerStoneItem(1));
    public static final RegistryObject<PowerStoneItem> POWER_STONE_2 =
        ITEMS.register("power_stone_2", () -> new PowerStoneItem(2));
    public static final RegistryObject<PowerStoneItem> POWER_STONE_3 =
        ITEMS.register("power_stone_3", () -> new PowerStoneItem(3));

    // Divine Armor
    public static final RegistryObject<DivineArmorItem> DIVINE_HELMET =
        ITEMS.register("divine_helmet", () -> new DivineArmorItem(net.minecraft.world.entity.EquipmentSlot.HEAD));
    public static final RegistryObject<DivineArmorItem> DIVINE_CHESTPLATE =
        ITEMS.register("divine_chestplate", () -> new DivineArmorItem(net.minecraft.world.entity.EquipmentSlot.CHEST));
    public static final RegistryObject<DivineArmorItem> DIVINE_LEGGINGS =
        ITEMS.register("divine_leggings", () -> new DivineArmorItem(net.minecraft.world.entity.EquipmentSlot.LEGS));
    public static final RegistryObject<DivineArmorItem> DIVINE_BOOTS =
        ITEMS.register("divine_boots", () -> new DivineArmorItem(net.minecraft.world.entity.EquipmentSlot.FEET));

    // Adam's Milk
    public static final RegistryObject<AdamsMilkItem> ADAMS_MILK =
        ITEMS.register("adams_milk", AdamsMilkItem::new);
}
