package com.divinesword.mod.armor;

import com.divinesword.mod.DivineSwordMod;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraftforge.common.ForgeSoundType;

public enum ModArmorMaterials implements ArmorMaterial {
    DIVINE("divine", 999, new int[]{20, 30, 28, 20}, 30,
        SoundEvents.ARMOR_EQUIP_NETHERITE, 20.0f, 0.1f);

    private static final int[] HEALTH_PER_SLOT = new int[]{13, 15, 16, 11};
    private final String name;
    private final int durabilityMultiplier;
    private final int[] protectionAmounts;
    private final int enchantmentValue;
    private final SoundEvent equipSound;
    private final float toughness;
    private final float knockbackResistance;

    ModArmorMaterials(String name, int durMult, int[] protection, int enchant,
                      SoundEvent sound, float tough, float kb) {
        this.name = name;
        this.durabilityMultiplier = durMult;
        this.protectionAmounts = protection;
        this.enchantmentValue = enchant;
        this.equipSound = sound;
        this.toughness = tough;
        this.knockbackResistance = kb;
    }

    public static void init() {} // force class load

    @Override public int getDurabilityForSlot(EquipmentSlot slot) { return HEALTH_PER_SLOT[slot.getIndex()] * durabilityMultiplier; }
    @Override public int getDefenseForSlot(EquipmentSlot slot) { return protectionAmounts[slot.getIndex()]; }
    @Override public int getEnchantmentValue() { return enchantmentValue; }
    @Override public SoundEvent getEquipSound() { return equipSound; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.EMPTY; }
    @Override public String getName() { return DivineSwordMod.MOD_ID + ":" + name; }
    @Override public float getToughness() { return toughness; }
    @Override public float getKnockbackResistance() { return knockbackResistance; }
}
